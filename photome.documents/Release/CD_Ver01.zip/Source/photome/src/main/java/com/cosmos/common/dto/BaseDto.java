/** 
 * 2013 BaseDto.java
 * Licensed to the Steven J.S Min. 
 * For use this source code, you must have to get right from the author. 
 * Unless enforcement is prohibited by applicable law, you may not modify, decompile, or reverse engineer Software.
 */

package com.cosmos.common.dto;

import java.io.Serializable;

/**
 * @author Steven J.S Min
 *
 */
public class BaseDto implements Serializable {

	private static final long serialVersionUID = 5025982847764609052L;

}
